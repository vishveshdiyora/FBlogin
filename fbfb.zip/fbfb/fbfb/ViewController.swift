//
//  ViewController.swift
//  fbfb
//
//  Created by Gaurav Parvadiya on 17/03/20.
//  Copyright © 2020 human.solutions. All rights reserved.
//

import UIKit
import FBSDKCoreKit
import FBSDKLoginKit

class ViewController: UIViewController {

    //MARK:- Outlets
    @IBOutlet weak var tokenid: UILabel!
    @IBOutlet weak var fbloginButton: UIButton!
    
    //MARK:- fbLoginOnclick Action
    @IBAction func fbLoginOnclick(_ sender: Any) {
        let login = LoginManager()
        if(AccessToken.current == nil){
            login.logIn(permissions: ["public_profile", "email"], from:self){ (result, error) in
            if let error = error {
              print("Failed to login: \(error.localizedDescription)")
              return
            }
                self.viewDidLoad()
            }
        }else{
            login.logOut()
            self.viewDidLoad()
        }
        
    }
        
    //MARK:- Lifecycles
    override func viewDidLoad() {
        super.viewDidLoad()
       
        if (AccessToken.current != nil) {
            tokenid.text = AccessToken.current?.tokenString
            fbloginButton.setTitle("Log Out", for: .normal)
        }
        else{
            tokenid.text = "Please Login"
            fbloginButton.setTitle("Click to FB login", for: .normal)
        }
    }
   
}



//
//  ViewController.swift
//  newfblogin
//
//  Created by Gaurav Parvadiya on 17/03/20.
//  Copyright © 2020 human.solutions. All rights reserved.
//

import UIKit
import FacebookCore
import FacebookLogin


class ViewController: UIViewController,LoginButtonDelegate {
    
    func loginButton(_ loginButton: FBLoginButton, didCompleteWith result: LoginManagerLoginResult?, error: Error?) {
        <#code#>
    }
    
    func loginButtonDidLogOut(_ loginButton: FBLoginButton) {
        <#code#>
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let loginButton = LoginButton(readPermissions: [.publicProfile])
    }


}

